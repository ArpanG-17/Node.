// Serverless function (Vercel). Keeps ANTHROPIC_API_KEY on the server —
// the browser never sees it. The frontend calls POST /api/generate
// with { prompt, maxTokens } and gets back the raw Anthropic response.

export default async function handler(request, response) {
  if (request.method !== "POST") {
    response.status(405).json({ error: "Method not allowed" });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    response
      .status(500)
      .json({ error: "Server is missing ANTHROPIC_API_KEY. Set it in your deployment's environment variables." });
    return;
  }

  const { prompt, maxTokens } = request.body || {};
  if (!prompt || typeof prompt !== "string") {
    response.status(400).json({ error: "Missing 'prompt' string in request body." });
    return;
  }

  const model = process.env.ANTHROPIC_MODEL || "claude-sonnet-5";
  const cappedMaxTokens = Math.min(Math.max(parseInt(maxTokens, 10) || 1200, 200), 4096);

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model,
        max_tokens: cappedMaxTokens,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    const data = await anthropicRes.json();

    if (!anthropicRes.ok) {
      response
        .status(anthropicRes.status)
        .json({ error: data?.error?.message || `Anthropic API error (${anthropicRes.status})` });
      return;
    }

    response.status(200).json(data);
  } catch (err) {
    response.status(500).json({ error: err?.message || "Server error calling the Anthropic API." });
  }
}
